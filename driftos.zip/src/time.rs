use uefi::table::{Boot, SystemTable};
use alloc::string::{String, ToString};

pub struct TimeManager {
    cached_time: String,
    cached_date: String,
    last_update: u64,
}

impl TimeManager {
    pub fn new() -> Self {
        Self {
            cached_time: String::from("00:00"),
            cached_date: String::from("Jan 1"),
            last_update: 0,
        }
    }

    pub fn get_time_string(&mut self, _system_table: &SystemTable<Boot>) -> &str {
        self.cached_time = String::from("12:34");
        &self.cached_time
    }

    pub fn get_date_string(&mut self, _system_table: &SystemTable<Boot>) -> &str {
        self.cached_date = String::from("Dec 25");
        &self.cached_date
    }

    pub fn get_formatted_datetime(&mut self, _system_table: &SystemTable<Boot>) -> String {
        "12:34 - Dec 25".to_string()
    }
}
