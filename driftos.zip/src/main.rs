#![no_std]
#![no_main]

extern crate alloc;

use uefi::prelude::*;
use uefi::table::{Boot, SystemTable};
use alloc::string::String;
use alloc::vec::Vec;
use alloc::vec;
use core::fmt::Write;

mod vga;
mod time;

#[entry]
fn main(_handle: Handle, mut system_table: SystemTable<Boot>) -> Status {
    uefi_services::init(&mut system_table).unwrap();
    
    system_table.stdout().clear().unwrap();
    writeln!(system_table.stdout(), "driftOS Rust Bootloader v1.0").unwrap();
    
    kernel_main(&mut system_table);
    
    shell_loop(&mut system_table);
    
    Status::SUCCESS
}

fn kernel_main(system_table: &mut SystemTable<Boot>) {
    writeln!(system_table.stdout(), "\n=== Welcome to driftOS v1.0! ===").unwrap();
    writeln!(system_table.stdout(), "Feel free to use the terminal tty interface").unwrap();
    writeln!(system_table.stdout(), "System Status: Online").unwrap();
    writeln!(system_table.stdout(), "Kernel: Rust-powered OS").unwrap();
    writeln!(system_table.stdout(), "Architecture: x86_64 UEFI").unwrap();
    writeln!(system_table.stdout(), "Ready for input...").unwrap();
    writeln!(system_table.stdout(), "Type 'help' for available commands.\n").unwrap();
}

fn shell_loop(system_table: &mut SystemTable<Boot>) {
    let mut input_buffer = [0u16; 256];
    let mut buffer_pos = 0;
    
    loop {
        write!(system_table.stdout(), "driftOS> ").unwrap();
        
        buffer_pos = 0;
        loop {
            let key = system_table.stdin().read_key().unwrap();
            
            if let Some(key) = key {
                match key {
                    uefi::proto::console::text::Key::Printable(char_code) => {
                        if char_code == uefi::Char16::try_from('\r').unwrap() {
                            writeln!(system_table.stdout(), "").unwrap();
                            break;
                        } else if char_code == uefi::Char16::try_from('\u{8}').unwrap() {
                            if buffer_pos > 0 {
                                buffer_pos -= 1;
                                write!(system_table.stdout(), "\u{8} \u{8}").unwrap();
                            }
                        } else if buffer_pos < input_buffer.len() - 1 {
                            input_buffer[buffer_pos] = u16::from(char_code);
                            buffer_pos += 1;
                            
                            if let Ok(display_char) = char::try_from(u16::from(char_code) as u32) {
                                write!(system_table.stdout(), "{}", display_char).unwrap();
                            }
                        }
                    }
                    uefi::proto::console::text::Key::Special(_) => {
                    }
                }
            }
        }
        
        input_buffer[buffer_pos] = 0;
        
        let command = utf16_to_string(&input_buffer[..buffer_pos]);
        let command = command.trim();
        
        if !command.is_empty() {
            execute_command(system_table, command);
        }
    }
}

fn utf16_to_string(utf16_slice: &[u16]) -> String {
    let mut result = String::new();
    for &code_unit in utf16_slice {
        if code_unit == 0 {
            break;
        }
        if let Some(ch) = char::from_u32(code_unit as u32) {
            result.push(ch);
        }
    }
    result
}

fn show_real_memory_info(system_table: &mut SystemTable<Boot>) {
    writeln!(system_table.stdout(), "Memory Information:").unwrap();
    
    let memory_map_size = system_table.boot_services().memory_map_size();
    let mut buffer = vec![0u8; memory_map_size.map_size + memory_map_size.entry_size * 2];
    
    match system_table.boot_services().memory_map(&mut buffer) {
        Ok(memory_map) => {
            let mut total_memory = 0u64;
            let mut usable_memory = 0u64;
            let mut reserved_memory = 0u64;
            let mut region_count = 0;
            
            for descriptor in memory_map.entries() {
                let pages = descriptor.page_count;
                let bytes = pages * 4096;
                
                total_memory += bytes;
                region_count += 1;
                
                match descriptor.ty {
                    uefi::table::boot::MemoryType::CONVENTIONAL => {
                        usable_memory += bytes;
                    }
                    uefi::table::boot::MemoryType::LOADER_CODE |
                    uefi::table::boot::MemoryType::LOADER_DATA |
                    uefi::table::boot::MemoryType::BOOT_SERVICES_CODE |
                    uefi::table::boot::MemoryType::BOOT_SERVICES_DATA |
                    uefi::table::boot::MemoryType::RUNTIME_SERVICES_CODE |
                    uefi::table::boot::MemoryType::RUNTIME_SERVICES_DATA => {
                        reserved_memory += bytes;
                    }
                    _ => {
                        reserved_memory += bytes;
                    }
                }
            }
            
            let total_mb = total_memory / (1024 * 1024);
            let usable_mb = usable_memory / (1024 * 1024);
            let reserved_mb = reserved_memory / (1024 * 1024);
            let used_mb = total_mb - usable_mb;
            
            writeln!(system_table.stdout(), "Total RAM: {} MB", total_mb).unwrap();
            writeln!(system_table.stdout(), "Available: {} MB", usable_mb).unwrap();
            writeln!(system_table.stdout(), "Used: {} MB", used_mb).unwrap();
            writeln!(system_table.stdout(), "Reserved: {} MB", reserved_mb).unwrap();
            writeln!(system_table.stdout(), "Memory Regions: {}", region_count).unwrap();
        }
        Err(_) => {
            writeln!(system_table.stdout(), "Error: Unable to read memory map").unwrap();
            writeln!(system_table.stdout(), "UEFI memory services unavailable").unwrap();
        }
    }
}

fn execute_command(system_table: &mut SystemTable<Boot>, command: &str) {
    let parts: Vec<&str> = command.split_whitespace().collect();
    if parts.is_empty() {
        return;
    }
    
    match parts[0] {
        "help" => {
            writeln!(system_table.stdout(), "Available commands:").unwrap();
            writeln!(system_table.stdout(), "  help     - Show this help message").unwrap();
            writeln!(system_table.stdout(), "  clear    - Clear the screen").unwrap();
            writeln!(system_table.stdout(), "  echo     - Echo text back").unwrap();
            writeln!(system_table.stdout(), "  info     - Show system information").unwrap();
            writeln!(system_table.stdout(), "  uptime   - Show system uptime").unwrap();
            writeln!(system_table.stdout(), "  version  - Show OS version").unwrap();
            writeln!(system_table.stdout(), "  ls       - List directory contents").unwrap();
            writeln!(system_table.stdout(), "  cat      - Display file contents").unwrap();
            writeln!(system_table.stdout(), "  pwd      - Show current directory").unwrap();
            writeln!(system_table.stdout(), "  whoami   - Show current user").unwrap();
            writeln!(system_table.stdout(), "  date     - Show current date and time").unwrap();
            writeln!(system_table.stdout(), "  uname    - Show system information").unwrap();
            writeln!(system_table.stdout(), "  mem      - Show memory information").unwrap();
            writeln!(system_table.stdout(), "  ps       - Show running processes").unwrap();
            writeln!(system_table.stdout(), "  history  - Show command history").unwrap();
            writeln!(system_table.stdout(), "  reboot   - Restart the system").unwrap();
            writeln!(system_table.stdout(), "  shutdown - Shutdown the system").unwrap();
        }
        "clear" => {
            system_table.stdout().clear().unwrap();
        }
        "echo" => {
            if parts.len() > 1 {
                let text = &command[5..];
                writeln!(system_table.stdout(), "{}", text).unwrap();
            } else {
                writeln!(system_table.stdout(), "Usage: echo <text>").unwrap();
            }
        }
        "info" => {
            writeln!(system_table.stdout(), "=== System Information ===").unwrap();
            writeln!(system_table.stdout(), "OS Name: driftOS").unwrap();
            writeln!(system_table.stdout(), "Version: 1.0").unwrap();
            writeln!(system_table.stdout(), "Architecture: x86_64").unwrap();
            writeln!(system_table.stdout(), "Firmware: UEFI").unwrap();
            writeln!(system_table.stdout(), "Language: Rust").unwrap();
        }
        "uptime" => {
            writeln!(system_table.stdout(), "System has been running since boot").unwrap();
        }
        "version" => {
            writeln!(system_table.stdout(), "driftOS version 1.0 (Rust-powered)").unwrap();
        }
        "ls" => {
            if parts.len() > 1 && parts[1] == "-l" {
                writeln!(system_table.stdout(), "total 8").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 bin").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 boot").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 dev").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 etc").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 home").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 lib").unwrap();
                writeln!(system_table.stdout(), "-rw-r--r--  1 root root  512 Dec 25 12:00 README.txt").unwrap();
                writeln!(system_table.stdout(), "-rw-r--r--  1 root root  256 Dec 25 12:00 version.txt").unwrap();
                writeln!(system_table.stdout(), "-rw-r--r--  1 root root  128 Dec 25 12:00 motd.txt").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 usr").unwrap();
                writeln!(system_table.stdout(), "drwxr-xr-x  2 root root 4096 Dec 25 12:00 var").unwrap();
            } else {
                writeln!(system_table.stdout(), "bin  boot  dev  etc  home  lib  README.txt  version.txt  motd.txt  usr  var").unwrap();
            }
        }
        "cat" => {
            if parts.len() > 1 {
                let filename = parts[1];
                match filename {
                    "README.txt" => {
                        writeln!(system_table.stdout(), "Welcome to driftOS!").unwrap();
                        writeln!(system_table.stdout(), "This is a Rust-based operating system.").unwrap();
                        writeln!(system_table.stdout(), "Built with UEFI support for modern hardware.").unwrap();
                        writeln!(system_table.stdout(), "").unwrap();
                        writeln!(system_table.stdout(), "Features:").unwrap();
                        writeln!(system_table.stdout(), "- Memory-safe kernel written in Rust").unwrap();
                        writeln!(system_table.stdout(), "- UEFI bootloader support").unwrap();
                        writeln!(system_table.stdout(), "- Interactive command-line interface").unwrap();
                        writeln!(system_table.stdout(), "- Modern x86_64 architecture support").unwrap();
                    }
                    "version.txt" => {
                        writeln!(system_table.stdout(), "driftOS v1.0").unwrap();
                        writeln!(system_table.stdout(), "Build: Release").unwrap();
                        writeln!(system_table.stdout(), "Kernel: Rust UEFI").unwrap();
                        writeln!(system_table.stdout(), "Compiler: rustc 1.70+").unwrap();
                        writeln!(system_table.stdout(), "Target: x86_64-unknown-uefi").unwrap();
                    }
                    "motd.txt" => {
                        writeln!(system_table.stdout(), "Message of the Day").unwrap();
                        writeln!(system_table.stdout(), "==================").unwrap();
                        writeln!(system_table.stdout(), "Welcome to driftOS - A modern Rust operating system!").unwrap();
                        writeln!(system_table.stdout(), "").unwrap();
                        writeln!(system_table.stdout(), "System is running smoothly.").unwrap();
                        writeln!(system_table.stdout(), "Type 'help' to see available commands.").unwrap();
                    }
                    _ => {
                        writeln!(system_table.stdout(), "cat: {}: No such file or directory", filename).unwrap();
                        writeln!(system_table.stdout(), "Available files: README.txt, version.txt, motd.txt").unwrap();
                    }
                }
            } else {
                writeln!(system_table.stdout(), "Usage: cat <filename>").unwrap();
            }
        }
        "pwd" => {
            writeln!(system_table.stdout(), "/home/user").unwrap();
        }
        "whoami" => {
            writeln!(system_table.stdout(), "root").unwrap();
        }
        "date" => {
            writeln!(system_table.stdout(), "Wed Dec 25 12:34:56 UTC 2024").unwrap();
        }
        "uname" => {
            if parts.len() > 1 && parts[1] == "-a" {
                writeln!(system_table.stdout(), "driftOS 1.0 x86_64 UEFI Rust").unwrap();
            } else {
                writeln!(system_table.stdout(), "driftOS").unwrap();
            }
        }
        "mem" => {
            show_real_memory_info(system_table);
        }
        "ps" => {
            writeln!(system_table.stdout(), "PID  COMMAND").unwrap();
            writeln!(system_table.stdout(), "  1  kernel").unwrap();
            writeln!(system_table.stdout(), "  2  shell").unwrap();
            writeln!(system_table.stdout(), "  3  idle").unwrap();
        }
        "history" => {
            writeln!(system_table.stdout(), "Command History:").unwrap();
            writeln!(system_table.stdout(), "  1  help").unwrap();
            writeln!(system_table.stdout(), "  2  info").unwrap();
            writeln!(system_table.stdout(), "  3  ls").unwrap();
            writeln!(system_table.stdout(), "  4  cat README.txt").unwrap();
            writeln!(system_table.stdout(), "  5  history").unwrap();
        }
        "reboot" => {
            writeln!(system_table.stdout(), "Rebooting system...").unwrap();
            system_table.runtime_services().reset(
                uefi::table::runtime::ResetType::COLD,
                Status::SUCCESS,
                None,
            );
        }
        "shutdown" => {
            writeln!(system_table.stdout(), "Shutting down system...").unwrap();
            system_table.runtime_services().reset(
                uefi::table::runtime::ResetType::SHUTDOWN,
                Status::SUCCESS,
                None,
            );
        }
        _ => {
            writeln!(system_table.stdout(), "Unknown command: '{}'. Type 'help' for available commands.", parts[0]).unwrap();
        }
    }
}

