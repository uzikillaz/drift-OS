#!/bin/bash

# Run driftOS in QEMU with UEFI firmware
qemu-system-x86_64 \
    -bios /usr/share/ovmf/OVMF.fd \
    -drive format=raw,file=fat:rw:disk_image \
    -m 256M \
    -enable-kvm \
    -cpu host \
    -smp 2 \
    -net none \
    -display gtk
